document.querySelector("#menu").addEventListener("click",function(){
    window.location.href="menu.html";
   })